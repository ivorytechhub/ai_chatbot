CREATE DATABASE chatbot_db;
USE chatbot_db;

CREATE TABLE chat_history (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_message TEXT,
  bot_reply TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
