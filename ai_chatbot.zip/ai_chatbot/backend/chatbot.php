<?php
include 'db_connect.php';
$message = $_POST['message'];

// Send message to the AI model
$ch = curl_init('http://127.0.0.1:5000/chat');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(["message" => $message]));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
$response = curl_exec($ch);
curl_close($ch);

$reply = json_decode($response, true)['reply'];

// Save chat in MySQL
$stmt = $conn->prepare("INSERT INTO chat_history (user_message, bot_reply) VALUES (?, ?)");
$stmt->bind_param("ss", $message, $reply);
$stmt->execute();
$stmt->close();
$conn->close();

echo $reply;
?>
