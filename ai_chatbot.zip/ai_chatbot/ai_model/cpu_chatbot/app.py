from flask import Flask, request, jsonify, render_template
import pandas as pd
import os
import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import SGDClassifier

app = Flask(__name__)

DATA_FILE = "conversations.csv"
MODEL_FILE = "chat_model.pkl"

# --- Load or create model ---
def load_model():
    if os.path.exists(MODEL_FILE):
        with open(MODEL_FILE, "rb") as f:
            vectorizer, model = pickle.load(f)
    else:
        if os.path.exists(DATA_FILE):
            df = pd.read_csv(DATA_FILE)
        else:
            df = pd.DataFrame({"input": ["hello", "hi", "bye"], "response": ["Hello! How are you?", "Hi there!", "Goodbye!"]})
            df.to_csv(DATA_FILE, index=False)

        vectorizer = TfidfVectorizer()
        X = vectorizer.fit_transform(df["input"])
        model = SGDClassifier()
        model.fit(X, df["response"])
        with open(MODEL_FILE, "wb") as f:
            pickle.dump((vectorizer, model), f)
    return vectorizer, model

vectorizer, model = load_model()

# --- Generate reply ---
def generate_reply(user_input):
    df = pd.read_csv(DATA_FILE)
    inputs = df["input"].tolist()

    # Check if known
    for i, q in enumerate(inputs):
        if q.lower() in user_input.lower():
            return df["response"][i]

    # If unknown — ask to teach
    return "Sorry, I don't understand that yet. Can you tell me what I should reply when you say this?"

# --- Learn new pair ---
def learn_new_response(user_input, new_response):
    df = pd.read_csv(DATA_FILE)
    df = pd.concat([df, pd.DataFrame({"input": [user_input], "response": [new_response]})], ignore_index=True)
    df.to_csv(DATA_FILE, index=False)

    global vectorizer, model
    X = vectorizer.fit_transform(df["input"])
    model.fit(X, df["response"])
    with open(MODEL_FILE, "wb") as f:
        pickle.dump((vectorizer, model), f)

# --- Routes ---
@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_input = data.get("message", "").strip()
    last_message = data.get("last_message", "")

    # If user is teaching
    if last_message.startswith("Sorry, I don't understand") and "you should respond" in user_input:
        try:
            parts = user_input.split("you should respond")
            question = parts[0].replace("When you are asked", "").strip()
            answer = parts[1].strip()
            learn_new_response(question, answer)
            return jsonify({"reply": f"Got it! Next time, I'll reply '{answer}' when you say '{question}'."})
        except:
            return jsonify({"reply": "Sorry, I couldn’t understand your teaching format."})

    # Otherwise generate
    reply = generate_reply(user_input)
    return jsonify({"reply": reply})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
