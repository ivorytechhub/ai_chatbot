document.getElementById('sendBtn').addEventListener('click', sendMessage);
document.getElementById('userInput').addEventListener('keypress', function(e) {
  if (e.key === 'Enter') sendMessage();
});

function sendMessage() {
  const msg = document.getElementById('userInput').value.trim();
  if (!msg) return;

  appendMessage('You', msg, 'user');
  document.getElementById('userInput').value = '';

  fetch('../backend/chatbot.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
    body: 'message=' + encodeURIComponent(msg)
  })
  .then(res => res.text())
  .then(reply => appendMessage('Bot', reply, 'bot'));
}

function appendMessage(sender, text, cls) {
  const msgDiv = document.createElement('div');
  msgDiv.className = `message ${cls}`;
  msgDiv.innerHTML = `<b>${sender}:</b> ${text}`;
  document.getElementById('messages').appendChild(msgDiv);
  document.getElementById('messages').scrollTop = document.getElementById('messages').scrollHeight;
}
